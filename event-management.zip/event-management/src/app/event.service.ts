

// import { Injectable } from '@angular/core';
// import { HttpClient } from '@angular/common/http';
// import { map, Observable } from 'rxjs';
// import { Event } from './event';

// @Injectable({
//   providedIn: 'root'
// })
// export class EventService {
//   editingUser: any = null;

//   private apiUrl = 'http://localhost:3000/events';

//   constructor(private http: HttpClient) {}

//   // Get all events
//   getEvents(): Observable<Event[]> {
//     return this.http.get<Event[]>(this.apiUrl);
//   }

//   // Get event by ID
//   getEvent(id: number): Observable<Event> {
//     return this.http.get<Event>(`${this.apiUrl}/${id}`);
//   }

//   // Create a new event
//   createEvent(event: Event): Observable<Event> {
//     return this.http.post<Event>(this.apiUrl, event);
//   }

//   // Update an event
//   updateEvent(event: Event): Observable<Event> {
//     return this.http.put<Event>(`${this.apiUrl}/${event.id}`, event);
//   }

//   // Delete an event
//   deleteEvent(id: number): Observable<void> {
//     return this.http.delete<void>(`${this.apiUrl}/${id}`);
//   }

//   // Register a user for an event
//   registerEvent(eventId: number, userData: any): Observable<Event> {
//     return this.http.patch<Event>(`${this.apiUrl}/${eventId}`, {
//       registrations: userData
//     });
//   }

//   // Check for duplicate events by name and date
//   checkDuplicateEvent(name: string, date: string): Observable<boolean> {
//     return this.http.get<Event[]>(this.apiUrl).pipe(
//       map((events: any[]) => events.some(event => event.name === name && event.date === date))
//     );
//   }

//   // User-related methods (consider moving to UserService)
//   postRegisteredUser(data: any): Observable<any> {
//     return this.http.post<any>('http://localhost:3000/registeredUsers', data);
//   }

//   getRegisteredUsers(): Observable<any[]> {
//     return this.http.get<any[]>('http://localhost:3000/registeredUsers');
//   }

//   deleteRegisteredUser(id: any): Observable<any> {
//     return this.http.delete<any>(`http://localhost:3000/registeredUsers/${id}`);
//   }

//   updateRegisteredUser(user: any): Observable<any> {
//     return this.http.put<any>(`http://localhost:3000/registeredUsers/${user.id}`, user);
//   }
  
// }

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map, Observable } from 'rxjs';
import { Event } from './event';

@Injectable({
  providedIn: 'root'
})
export class EventService {
  editingUser: any = null;

  private apiUrl = 'http://localhost:3000/events';
  private registeredUsersUrl = 'http://localhost:3000/registeredUsers';

  constructor(private http: HttpClient) {}

  // Get all events
  getEvents(): Observable<Event[]> {
    return this.http.get<Event[]>(this.apiUrl);
  }

  // Get event by ID
  getEvent(id: number): Observable<Event> {
    return this.http.get<Event>(`${this.apiUrl}/${id}`);
  }

  // Create a new event
  createEvent(event: Event): Observable<Event> {
    return this.http.post<Event>(this.apiUrl, event);
  }

  // Update an event
  updateEvent(event: Event): Observable<Event> {
    return this.http.put<Event>(`${this.apiUrl}/${event.id}`, event);
  }

  // Delete an event
  deleteEvent(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }

  // Register a user for an event
  registerEvent(eventId: number, userData: any): Observable<Event> {
    return this.http.patch<Event>(`${this.apiUrl}/${eventId}`, {
      registrations: userData
    });
  }

  // Check for duplicate events by name and date
  checkDuplicateEvent(name: string, date: string): Observable<boolean> {
    return this.http.get<Event[]>(this.apiUrl).pipe(
      map((events: any[]) => events.some(event => event.name === name && event.date === date))
    );
  }

  // Register a user
  postRegisteredUser(data: any): Observable<any> {
    return this.http.post<any>(this.registeredUsersUrl, data);
  }

  // Get all registered users
  getRegisteredUsers(): Observable<any[]> {
    return this.http.get<any[]>(this.registeredUsersUrl).pipe(
      map((res) => {
        console.log('Response from API:', res); // Check the response
        return res;
      })
    );
  }
  

  // Delete a registered user
  deleteRegisteredUser(id: any): Observable<any> {
    return this.http.delete<any>(`${this.registeredUsersUrl}/${id}`);
  }

  // Update a registered user
  updateRegisteredUser(user: any): Observable<any> {
    return this.http.put<any>(`http://localhost:3000/registeredUsers/${user.id}`, user);
  }
}
