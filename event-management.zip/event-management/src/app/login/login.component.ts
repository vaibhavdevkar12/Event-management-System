import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  username: string = '';
  password: string = '';
  errorMessage: string = '';

  constructor(private router: Router) {}

  onSubmit(): void {
    if (this.username === 'admin' && this.password === 'admin123') {
      localStorage.setItem('user', JSON.stringify({ role: 'admin', username: this.username }));
      this.router.navigate(['/home']);
    } else if (this.username === 'user' && this.password === 'user123') {
      localStorage.setItem('user', JSON.stringify({ role: 'user', username: this.username }));
      this.router.navigate(['/home']);
    } else {
      this.errorMessage = 'Invalid credentials';
    }
  }
}
