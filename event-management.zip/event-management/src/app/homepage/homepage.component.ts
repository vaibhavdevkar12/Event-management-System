import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.css']
})
export class HomepageComponent {

  constructor(private router: Router) {}

  onEvent() {
    this.router.navigate(['/events']);
  }

  onCreate() {
    this.router.navigate(['/create']);
  }

  onView() {
    this.router.navigate(['/view']);
  }

  // Check if the logged-in user is admin
  isAdmin(): boolean {
    const user = JSON.parse(localStorage.getItem('user') || '{}');
    return user && user.role === 'admin';
  }

  // Check if the logged-in user is a regular user
  isUser(): boolean {
    const user = JSON.parse(localStorage.getItem('user') || '{}');
    return user && user.role === 'user';
  }
}
