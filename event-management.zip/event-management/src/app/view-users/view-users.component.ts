import { AfterViewInit, Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EventService } from '@app/event.service';

@Component({
  selector: 'app-view-users',
  templateUrl: './view-users.component.html',
  styleUrls: ['./view-users.component.css']
})
export class ViewUsersComponent implements OnInit {
  allEvents: any[] = [];
  registeredEvents: any[] = [];
  selectedEvent: any;

  constructor(private apiServices: EventService, private router: Router) {}

  ngOnInit(): void {
    // Fetch all events
    this.apiServices.getEvents().subscribe((res) => {
      this.allEvents = res;
    });

    // Fetch all registered users
    this.apiServices.getRegisteredUsers().subscribe((res) => {
      this.registeredEvents = res;
    });
  }

  // Select event from the dropdown
  onEventSelect(event: any): void {
    this.selectedEvent = event;
  }

  // Handle user deletion
  onDelete(user: any): void {
    const confirmation = window.confirm('Are you sure you want to delete this user?');
    if (confirmation) {
      this.apiServices.deleteRegisteredUser(user.id).subscribe(() => {
        this.getAllUsers();
      });
    }
  }
  

  // Refresh the list of registered users
  getAllUsers(): void {
    this.apiServices.getRegisteredUsers().subscribe((res) => {
      this.registeredEvents = res;
    });
  }

  // Handle user editing
  onEdit(user: any): void {
    console.log('Editing user with eventName:', user.eventName, 'and id:', user.id);
    this.apiServices.editingUser = user;
    this.router.navigate(['/register', user.eventName]);
  }
}
