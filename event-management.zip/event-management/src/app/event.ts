export interface Event {
    stopPropagation(): unknown;
    id: number;
    name: string;
    date: string;
    location: string;
    description: string;
  }
  
  export class RegisteredUsers{
    name:string='';
    email:string='';
    eventName:string='';
  }

  export class EventService {
    editingUser: any = null;
  
    
  }