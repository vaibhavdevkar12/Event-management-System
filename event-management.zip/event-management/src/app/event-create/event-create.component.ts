

import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { EventService } from '../event.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-event-create',
  templateUrl: './event-create.component.html',
  styleUrls: ['./event-create.component.css']
})
export class EventCreateComponent implements OnInit {
  eventForm!: FormGroup;

  constructor(
    private fb: FormBuilder,
    private eventService: EventService,
    private router: Router,
    private route: ActivatedRoute
  ) {}
  ngOnInit(): void {
    this.eventForm = this.fb.group({
      name: ['', Validators.required],
      startDate: ['', [Validators.required, this.minDateValidator]],
      endDate: ['', [Validators.required, this.endDateValidator.bind(this)]],
      location: ['', Validators.required],
      description: ['', [Validators.required, Validators.minLength(10)]],
    });

    const eventId = this.route.snapshot.params['id'];
  if (eventId) {
    this.eventService.getEvent(eventId).subscribe((event: any) => {
      this.eventForm.patchValue(event);
    });
  }
  }

  minDateValidator(control: any): { [key: string]: boolean } | null {
    const currentDate = new Date();
    const selectedDate = new Date(control.value);
    return selectedDate >= currentDate ? null : { minDate: true };
  }

  // endDateValidator(control: any): { [key: string]: boolean } | null {
  //   const existstartDate = this.eventForm.value.startDate;
  //   const existEndDate = this.eventForm.value.endDate;
  //   const eventName = this.eventForm.value.name
  //   const existingEvents:boolean = false

  //   this.eventService.getEvents().subscribe(res=>{
  //     const existingEvents = res.find((res:any)=>{
  //       res.name === eventName && res.startDate === existstartDate
  //     })
  //   })

  //   if(existingEvents){
  //     this.eventForm.controls['name'].setErrors({customError:'You can not create same event'});
  //   }
    
  //   const startDate = new Date(this.eventForm?.get('startDate')?.value);
  //   const endDate = new Date(control.value);
  //   return endDate >= startDate ? null : { minDate: true };
  // }

  endDateValidator(control: any): { [key: string]: boolean } | null {
    const existStartDate = this.eventForm?.value?.startDate;
    const eventName = this.eventForm?.value?.name;
  
    // Safeguard: Ensure startDate and name are defined
    if (!existStartDate || !eventName) {
      return null;
    }
  
    // Call the eventService to check if the event already exists
    this.eventService.getEvents().subscribe((res: any[]) => {
      const existingEvent = res.find(
        (event: any) =>
          event.name === eventName && event.startDate === existStartDate
      );
  
      // If the event already exists, set a custom error on the name field
      if (existingEvent) {
        this.eventForm.controls['name']?.setErrors({
          customError: 'You cannot create the same event',
        });
      }
    });
  
    // Validate that the end date is after the start date
    const startDate = new Date(existStartDate);
    const endDate = new Date(control.value);
    return endDate >= startDate ? null : { minDate: true };
  }

  // onSubmit(): void {
  //   if (this.eventForm.valid) {
  //     this.eventService.createEvent(this.eventForm.value).subscribe(() => {
  //       this.router.navigate(['/events']);
  //     });
  //   }
  // }

  onSubmit(): void {
    if (this.eventForm.valid) {
      const eventId = this.route.snapshot.params['id'];
      if (eventId) {
        // Update existing event
        this.eventService.updateEvent({ id: eventId, ...this.eventForm.value }).subscribe(() => {
          this.router.navigate(['/events']);
        });
      } else {
        // Create new event
        this.eventService.createEvent(this.eventForm.value).subscribe(() => {
          this.router.navigate(['/events']);
        });
      }
    }
  }
  
}
