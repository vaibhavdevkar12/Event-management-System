import { NgFor, NgIf } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { EventService } from '@app/event.service';
import { ActivatedRoute, Router } from '@angular/router';
import { RegisteredUsers } from '@app/event';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [ReactiveFormsModule, NgIf, NgFor],
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css'],
})
export class RegisterComponent implements OnInit {
  eventId!: string;
  events: any[] = [];
  selectedEvent: any;
  EventObj = new RegisteredUsers();
  registrationForm: FormGroup;
  registeredEvent: any;
  editEvent: any;

  allEvents: any[] = [];
  registeredEvents: any[] = [];
  registeredUsers: any;

  constructor(
    private fb: FormBuilder,
    private eventService: EventService,
    private route: ActivatedRoute,
    private router: Router
  ) {
    this.registrationForm = this.fb.group({
      name: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      event: ['', Validators.required],
    });
  }

  ngOnInit(): void {
    this.loadEvents();
    this.loadEditingUser();

    this.eventService.getEvents().subscribe((res) => {
      this.allEvents = res;
    });

    this.eventService.getRegisteredUsers().subscribe((res) => {
      this.registeredEvents = res;
    });
  }

  loadEvents(): void {
    this.route.paramMap.subscribe((params) => {
      this.eventId = params.get('id')!;
      console.log('Event ID:', this.eventId);

      this.eventService.getEvents().subscribe((res) => {
        this.events = res;

        if (this.eventId) {
          this.selectedEvent = this.events.find((event) => event.id === this.eventId);

          if (this.selectedEvent) {
            this.registrationForm.patchValue({
              event: this.selectedEvent.id,
            });
          }
        }
      });
    });
  }

  loadEditingUser(): void {
    if (this.eventService.editingUser) {
      const editingUser = this.eventService.editingUser;
      console.log('Editing User:', editingUser);

      this.editEvent = editingUser.eventName;

      this.registrationForm.patchValue({
        name: editingUser.name,
        email: editingUser.email,
        event: this.selectedEvent?.id || editingUser.eventName,
      });

      console.log('Form patched for editing user');
    } else {
      console.log('Creating a new user');
    }
  }

  onSubmit(): void {
    if (this.registrationForm.valid) {
      const formValue = this.registrationForm.value;
      
      if (this.eventService.editingUser) {
        // Update existing user
        const updatedUser = {
          ...this.eventService.editingUser,
          name: formValue.name,
          email: formValue.email,
          eventName: this.selectedEvent?.name,
        };
  
        this.eventService.updateRegisteredUser(updatedUser).subscribe(
          (response) => {
            console.log('User updated successfully:', response);
            alert('User updated successfully!');
            this.eventService.editingUser = null;
            this.resetForm();
            this.getAllUsers(); // Re-fetch registered users
          },
          (error) => {
            console.error('Failed to update user:', error);
            this.getAllUsers(); // Ensure re-fetch
          }
        );
      } else {
        // Register new user
        const newUser = {
          name: formValue.name,
          email: formValue.email,
          eventName: this.selectedEvent?.name,
        };
  
        this.eventService.postRegisteredUser(newUser).subscribe(
          (response) => {
            console.log('User registered successfully:', response);
            alert('User registered successfully!');
            this.resetForm();
            this.getAllUsers(); // Re-fetch registered users
          },
          (error) => {
            console.error('Failed to register user:', error);
          }
        );
      }
    } else {
      alert('Form is not valid');
    }
  }
  

  resetForm(): void {
    this.registrationForm.reset();
    this.registrationForm.patchValue({
      event: this.selectedEvent?.id || '',
    });
    this.eventService.editingUser = null;
  }

  onEventSelect(event: any): void {
    this.selectedEvent = event;
  }

  onDelete(user: any): void {
    const confirmation = window.confirm('Are you sure you want to DELETE this user?');
    if (confirmation) {
      this.eventService.deleteRegisteredUser(user.id).subscribe(() => {
        this.getAllUsers();
        // alert('User deleted successfully!');
      });
    }
  }

  getAllUsers(): void {
    console.log('Selected event:', this.selectedEvent); // Check if it's correctly set
    this.eventService.getRegisteredUsers().subscribe((res: any[]) => {
      console.log('Registered users:', res);
      this.registeredEvents = res.filter(
        (event) => event.eventName === this.selectedEvent?.name
      );
    });
  }
  
  

  onEdit(user: any): void {
    const confirmation = window.confirm('Are you sure you want to EDIT this user?');
    if (confirmation) {
      console.log('Editing user with eventName:', user.eventName, 'and id:', user.id);

      this.eventService.editingUser = user;

      this.registrationForm.patchValue({
        name: user.name,
        email: user.email,
        event: user.eventName,
      });
    }

    this.getAllUsers();
  }

  isAdmin(): boolean {
    const user = JSON.parse(localStorage.getItem('user') || '{}');
    return user && user.role === 'admin';
  }
}
