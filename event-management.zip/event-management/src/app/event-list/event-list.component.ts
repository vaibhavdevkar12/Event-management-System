import { Component, OnInit } from '@angular/core';
import { EventService } from '../event.service';
import { Event } from '../event'; 
import { Route, Router, RouterLinkActive } from '@angular/router';



@Component({
  selector: 'app-event-list',
  templateUrl: './event-list.component.html',
  styleUrls: ['./event-list.component.css']
})
export class EventListComponent implements OnInit {
  events: Event[] = [];

  constructor(private eventService: EventService,private router:Router) { }

  ngOnInit(): void {
    this.eventService.getEvents().subscribe(events => this.events = events);
  }
  onRegister(event: any): void {
    this.router.navigate(['/register', event.id]);
  }


  onDelete(event: Event): void {
    const confirmation = window.confirm('Are you sure you want to DELETE this event?');
    if (confirmation) {
      this.eventService.deleteEvent(event.id).subscribe(() => {
        this.getAllUsers(); // Refresh the event list after deletion
        // alert('Event deleted successfully');
      });
    }
  }
  

  getAllUsers(){
    this.eventService.getEvents().subscribe((res) => {
      this.events = res
    });
  }

  onEdit(event: Event): void {
    const confirmation = window.confirm('Are you sure you want to EDIT this event?');
    if (confirmation) {
      this.router.navigate(['/edit', event.id]);
    }
  }

  isAdmin(): boolean {
    const user = JSON.parse(localStorage.getItem('user') || '{}');
    return user && user.role === 'admin';
  }

  // Check if the logged-in user is a regular user
  isUser(): boolean {
    const user = JSON.parse(localStorage.getItem('user') || '{}');
    return user && user.role === 'user';
  }
}

