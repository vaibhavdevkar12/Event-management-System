import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filterByEvent',
  standalone: true,
})
export class FilterByEventPipe implements PipeTransform {
  transform(users: any[], eventName: string): any[] {
    if (!users || !eventName) {
      return [];
    }
    return users.filter(user => user.eventName === eventName);
  }
}
