// Import FormsModule for two-way binding
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AuthGuard } from './auth.gaurd';
import { LoginComponent } from './login/login.component';
import { AppComponent } from './app.component';
import { EventListComponent } from './event-list/event-list.component';
import { EventDetailsComponent } from './event-details/event-details.component';
import { EventCreateComponent } from './event-create/event-create.component';
import { HomepageComponent } from './homepage/homepage.component';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { ViewUsersComponent } from './view-users/view-users.component';
import { NgFor, NgIf } from '@angular/common';

@NgModule({
  declarations: [
    AppComponent,
    EventListComponent,
    EventDetailsComponent,
    EventCreateComponent,
    HomepageComponent,
    LoginComponent,
    ViewUsersComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    AppRoutingModule,
  ],
  providers: [AuthGuard],
  bootstrap: [AppComponent],
})
export class AppModule {}
