import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {

  constructor(private router: Router) {}

  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): boolean {
    // Get the user object from localStorage
    const user = JSON.parse(localStorage.getItem('user') || '{}');

    // Check if the user is logged in and has the 'admin' role
    if (user && user.role === 'admin') {
      return true;
    } else {
      // If not admin, redirect to the homepage or login page
      this.router.navigate(['/home']);
      return false;
    }
  }
}
