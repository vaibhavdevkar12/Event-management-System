

import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent implements OnInit {
  title = 'Event Management System';
  events = [
    { id: 1, name: 'Event 1' },
    { id: 2, name: 'Event 2' },
    { id: 3, name: 'Event 3' },
  ];
  registeredEvents: any[] = [];

  constructor(private router: Router) {}

  ngOnInit(): void {
    // Initialize the registered events from localStorage
    const storedEvents = localStorage.getItem('registeredEvents');
    if (storedEvents) {
      this.registeredEvents = JSON.parse(storedEvents);
    }
  }

  isLoggedIn(): boolean {
    return !!localStorage.getItem('user');
  }

  onLogout(): void {
    localStorage.removeItem('user');
    this.router.navigate(['/login']);
  }

  onRegister(event: any): void {
    // Check if the event is already registered
    const isAlreadyRegistered = this.registeredEvents.some(e => e.id === event.id);

    if (!isAlreadyRegistered) {
      // Add the event to the registered events array
      this.registeredEvents.push(event);
      // Save the registered events to localStorage
      localStorage.setItem('registeredEvents', JSON.stringify(this.registeredEvents));
      alert('Event registered successfully!');
    } else {
      alert('You have already registered for this event.');
    }
  }
}
